// MARK: - ... Вычислимые свойства
extension Double {
    var km: Double { return self * 1_000 }
    var m: Double { return self }
    var cm: Double { return self / 100 }
    var mm: Double { return self / 1_000 }
    var ft: Double { return self / 3.28084  }
}

let oneInch = 2.54.cm
let threeFeet = 3.ft
let marathonDistance = 42.km + 195.m

// MARK: - ... Конструкторы
struct Size {
    var width = 0.0, height = 0.0
}

struct Point {
    var x = 0.0, y = 0.0
}

struct Rect {
    var origin = Point()
    var size = Size()
}

let defaultRect = Rect()
let memberwiseRect = Rect(origin: Point(x: 2, y: 2), size: Size(width: 5, height: 5))

extension Rect {
    init(center: Point, size: Size) {
        let originX = center.x - size.width / 2
        let originY = center.y - size.height / 2
        self.init(origin: Point(x: originX, y: originY), size: size)
    }
}

let centerRect = Rect(center: Point(x: 4, y: 4), size: Size(width: 3, height: 3))
print(centerRect)

// MARK: - ... Методы
extension Int {
    func repetitions(task: () -> Void) {
        for _ in 1...self {
            task()
        }
    }
}

3.repetitions {
    print("Привет!")
}

extension Int {
    mutating func square() {
        self = self * self
    }
}

var three = 3
three.square()
print(three)

// MARK: - ... Индексы
// 123456789[0] -> 9
// 123456789[1] -> 8
extension Int {
    subscript(digitIndex: Int) -> Int {
        var decimalBase = 1
        for _ in 0..<digitIndex {
            decimalBase *= 10
        }
        return (self / decimalBase) % 10
    }
}
987654321[0]
987654321[1]

for i in 0...10 {
    print("987654321[\(i)] =", 987654321[i])
}

// MARK: ... - Вложенные типы
extension Int {
    enum Kind {
        case negative, zero, positive
    }
    var kind: Kind {
        switch self {
        case 0:
            return .zero
        case let x where x < 0:
            return .negative
        default:
            return .positive
        }
    }
}
print(5.kind)
print(type(of: 5.kind))

let x: Int.Kind = 0.kind

func printIntegerKinds(_ numbers: [Int]) {
    for number in numbers {
        switch number.kind {
        case .negative:
            print("- ", terminator: "")
        case .zero:
            print("0 ", terminator: "")
        case .positive:
            print("+ ", terminator: "")
        }
    }
}

printIntegerKinds([3, 19, -27, 0, -6, 0, 7])

// MARK: - ... Расширения протоколов
protocol RandomNumberProtocol {
    func random() -> Double
}

class RandomGenerator: RandomNumberProtocol {
    func random() -> Double {
        return Double.random(in: 0...1)
    }
}

extension RandomNumberProtocol {
    func randomBool() -> Bool {
        return random() > 0.5
    }
}

let r = RandomGenerator()
r.random()
r.randomBool()
r.random()
r.randomBool()
r.random()
r.randomBool()
r.random()
r.randomBool()

extension Collection where Element: Equatable {
    func allEqual() -> Bool {
        for element in self {
            if element != self.first {
                return false
            }
        }
        return true
    }
}

[100, 100, 100, 100, 100, 100, 100, 100].allEqual()
[100, 100, 100, 200, 100, 100, 100, 100].allEqual()
//[100, 0.0, ""].allEqual()
